package com.hospital.exceptions;

public class TitleNotFoundException extends Throwable {
    public TitleNotFoundException(String s) {
        super(s);
    }
}
